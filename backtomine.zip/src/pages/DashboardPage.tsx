import { useCallback, useState } from 'react'
import { ApiKeyGate } from '@/components/ApiKeyGate'
import { TaskSidebar } from '@/components/TaskSidebar'
import { TaskDetail } from '@/components/TaskDetail'
import type { TaskSummary } from '@/types'

export function DashboardPage() {
  const [hasKey, setHasKey] = useState<boolean>(!!localStorage.getItem('api_key'))
  const [authError, setAuthError] = useState<string | undefined>()
  const [tasks, setTasks] = useState<TaskSummary[]>([])
  const [selectedId, setSelectedId] = useState<number | null>(null)

  function handleKeySet() {
    setAuthError(undefined)
    setHasKey(true)
  }

  function handleUnauthorized() {
    localStorage.removeItem('api_key')
    setHasKey(false)
    setAuthError('API key rejected — please enter a valid key.')
  }

  function handleTaskCreated(task: TaskSummary) {
    setTasks(prev => [...prev, task])
    setSelectedId(task.id)
  }

  const handleStatusChange = useCallback((taskId: number, status: string) => {
    setTasks(prev =>
      prev.map(t => t.id === taskId ? { ...t, status: status as TaskSummary['status'] } : t)
    )
  }, [])

  if (!hasKey) {
    return <ApiKeyGate onKeySet={handleKeySet} errorMessage={authError} />
  }

  return (
    <div className="flex h-full overflow-hidden">
      <TaskSidebar
        tasks={tasks}
        selectedId={selectedId}
        onSelect={setSelectedId}
        onTaskCreated={handleTaskCreated}
        onUnauthorized={handleUnauthorized}
      />
      <main className="flex-1 overflow-hidden">
        {selectedId === null ? (
          <div className="flex h-full items-center justify-center p-12">
            <div className="max-w-md space-y-6">
              <div>
                <h1 className="font-mono text-xl font-bold text-[#e6edf3]">
                  Ready when you are
                </h1>
                <p className="mt-2 text-sm leading-relaxed text-[#8b949e]">
                  Describe a task in the sidebar and a team of AI agents will research, analyze, and report back — live.
                </p>
              </div>

              <div className="rounded border border-[#21262d] bg-[#161b22] px-4 py-3">
                <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-[#484f58]">Try asking</p>
                <ul className="space-y-1">
                  {[
                    'What is the current population of Tokyo?',
                    'Summarize the latest developments in quantum computing',
                    'Compare the pros and cons of electric vs hybrid cars',
                  ].map(example => (
                    <li key={example} className="text-xs text-[#8b949e]">› {example}</li>
                  ))}
                </ul>
              </div>

              <p className="font-mono text-xs text-[#484f58]">
                ← type your task in the sidebar to begin
              </p>
            </div>
          </div>
        ) : (
          <TaskDetail
            key={selectedId}
            taskId={selectedId}
            onStatusChange={handleStatusChange}
          />
        )}
      </main>
    </div>
  )
}
